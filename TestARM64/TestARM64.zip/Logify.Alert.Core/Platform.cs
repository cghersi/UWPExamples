﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevExpress.Logify.Core.Internal {
    public enum Platform {
        WIN,
        WPF,
        ASP,
        NETCORE_ASP,
        NETCORE_CONSOLE,
        XAMARIN_ANDROID,
        XAMARIN_IOS,
        UWP,
        NONE
    }
}
